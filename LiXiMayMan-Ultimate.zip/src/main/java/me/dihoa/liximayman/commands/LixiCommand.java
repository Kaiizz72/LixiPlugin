package me.dihoa.liximayman.commands;

import me.dihoa.liximayman.managers.LixiManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LixiCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Chỉ người chơi mới dùng được lệnh này.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§eDùng /lixi help để xem hướng dẫn.");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help" -> {
                player.sendMessage("§e===== Hướng dẫn Lì Xì =====");
                player.sendMessage("/lixi give <player> <amount>");
                player.sendMessage("/lixi share <player1> <player2> ... <amount>");
                player.sendMessage("/lixi all <amount>");
                player.sendMessage("/lixi random <amount>");
            }
            case "give" -> {
                if (args.length < 3) {
                    player.sendMessage("§c/lixi give <player> <amount>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage("§cNgười chơi không tồn tại.");
                    return true;
                }
                try {
                    double amount = Double.parseDouble(args[2]);
                    LixiManager.sendLixiMoney(player, List.of(target), amount);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cSố tiền không hợp lệ.");
                }
            }
            case "share" -> {
                if (args.length < 3) {
                    player.sendMessage("§c/lixi share <player1> <player2> ... <amount>");
                    return true;
                }
                try {
                    double amount = Double.parseDouble(args[args.length - 1]);
                    List<Player> receivers = new ArrayList<>();
                    for (int i = 1; i < args.length - 1; i++) {
                        Player p = Bukkit.getPlayer(args[i]);
                        if (p != null && p.isOnline()) receivers.add(p);
                    }
                    LixiManager.sendLixiMoney(player, receivers, amount);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cSố tiền không hợp lệ.");
                }
            }
            case "all" -> {
                if (args.length < 2) {
                    player.sendMessage("§c/lixi all <amount>");
                    return true;
                }
                try {
                    double amount = Double.parseDouble(args[1]);
                    List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
                    online.remove(player);
                    LixiManager.sendLixiMoney(player, online, amount);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cSố tiền không hợp lệ.");
                }
            }
            case "random" -> {
                if (args.length < 2) {
                    player.sendMessage("§c/lixi random <amount>");
                    return true;
                }
                try {
                    double amount = Double.parseDouble(args[1]);
                    List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
                    online.remove(player);
                    if (online.isEmpty()) {
                        player.sendMessage("§cKhông có người chơi khác online.");
                        return true;
                    }
                    int count = Math.min(3, online.size());
                    java.util.Collections.shuffle(online);
                    List<Player> chosen = online.subList(0, count);
                    LixiManager.sendLixiMoney(player, chosen, amount);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cSố tiền không hợp lệ.");
                }
            }
            default -> player.sendMessage("§cLệnh không hợp lệ. Dùng /lixi help.");
        }
        return true;
    }
}
