package me.dihoa.liximayman.guis;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GUIAmount {
    public static void open(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, "§aChọn số tiền/point");

        addItem(gui, 10, Material.PAPER, "§f100");
        addItem(gui, 11, Material.PAPER, "§f500");
        addItem(gui, 12, Material.PAPER, "§f1000");
        addItem(gui, 13, Material.PAPER, "§f5000");
        addItem(gui, 14, Material.PAPER, "§f10000");

        addItem(gui, 22, Material.EMERALD_BLOCK, "§aXác nhận");

        player.openInventory(gui);
    }

    private static void addItem(Inventory gui, int slot, Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        gui.setItem(slot, item);
    }
}
