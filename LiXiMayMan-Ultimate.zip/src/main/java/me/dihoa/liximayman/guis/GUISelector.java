package me.dihoa.liximayman.guis;

import me.dihoa.liximayman.utils.LixiSession;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GUISelector {
    public static void openTypeSelector(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, "§6Chọn loại lì xì");

        ItemStack money = new ItemStack(Material.GOLD_INGOT);
        ItemMeta moneyMeta = money.getItemMeta();
        moneyMeta.setDisplayName("§eLì xì bằng Money");
        money.setItemMeta(moneyMeta);

        ItemStack point = new ItemStack(Material.DIAMOND);
        ItemMeta pointMeta = point.getItemMeta();
        pointMeta.setDisplayName("§bLì xì bằng Point");
        point.setItemMeta(pointMeta);

        gui.setItem(11, money);
        gui.setItem(15, point);

        player.openInventory(gui);
    }
}
