package me.dihoa.liximayman.guis;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GUIMode {
    public static void open(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, "§bChọn chế độ phát lì xì");

        addItem(gui, 10, Material.NAME_TAG, "§aPhát cá nhân", "§7Chọn người nhận cụ thể");
        addItem(gui, 12, Material.BEACON, "§eChia đều toàn bộ người chơi", "§7Gửi cho tất cả online");
        addItem(gui, 14, Material.ENDER_PEARL, "§dNgẫu nhiên vài người", "§7Phát random");

        player.openInventory(gui);
    }

    private static void addItem(Inventory gui, int slot, Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(java.util.Collections.singletonList(lore));
        item.setItemMeta(meta);
        gui.setItem(slot, item);
    }
}
