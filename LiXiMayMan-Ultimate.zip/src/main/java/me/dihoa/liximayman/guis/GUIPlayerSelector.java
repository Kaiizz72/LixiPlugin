package me.dihoa.liximayman.guis;

import me.dihoa.liximayman.utils.LixiSession;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class GUIPlayerSelector {
    public static void open(Player opener) {
        Inventory gui = Bukkit.createInventory(null, 54, "§aChọn người nhận lì xì");

        int slot = 0;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (slot >= 45) break; // tránh tràn
            if (target.equals(opener)) continue;

            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) skull.getItemMeta();
            meta.setOwningPlayer(target);
            meta.setDisplayName("§e" + target.getName());
            skull.setItemMeta(meta);

            gui.setItem(slot++, skull);
        }

        ItemStack confirm = new ItemStack(Material.EMERALD_BLOCK);
        SkullMeta meta = (SkullMeta) confirm.getItemMeta();
        meta.setDisplayName("§aXác nhận gửi lì xì");
        confirm.setItemMeta(meta);
        gui.setItem(49, confirm);

        opener.openInventory(gui);
    }
}
