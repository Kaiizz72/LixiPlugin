package me.dihoa.liximayman.listeners;

import me.dihoa.liximayman.guis.GUISelector;
import me.dihoa.liximayman.utils.LixiSession;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class GUIListener implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getCurrentItem() == null) return;

        String title = e.getView().getTitle();
        ItemStack item = e.getCurrentItem();
        e.setCancelled(true);

        if (title.equals("§6Chọn loại lì xì")) {
            if (item.getType() == Material.GOLD_INGOT) {
                LixiSession.setType(player.getUniqueId(), LixiSession.LixiType.MONEY);
                player.closeInventory();
                player.sendMessage("§aBạn đã chọn Lì Xì bằng Money.");
                // TODO: Mở GUI nhập tiền
            } else if (item.getType() == Material.DIAMOND) {
                LixiSession.setType(player.getUniqueId(), LixiSession.LixiType.POINT);
                player.closeInventory();
                player.sendMessage("§bBạn đã chọn Lì Xì bằng Point.");
                // TODO: Mở GUI nhập point
            }
        }
    }
}

        if (title.equals("§aChọn số tiền/point")) {
            if (item.getType() == Material.PAPER) {
                try {
                    int amount = Integer.parseInt(item.getItemMeta().getDisplayName().replace("§f", ""));
                    LixiSession.setAmount(player.getUniqueId(), amount);
                    player.sendMessage("§eBạn đã chọn số tiền/point: " + amount);
                } catch (Exception ignored) {}
            } else if (item.getType() == Material.EMERALD_BLOCK) {
                int amount = LixiSession.getAmount(player.getUniqueId());
                LixiSession.LixiType type = LixiSession.getType(player.getUniqueId());
                player.closeInventory();
                player.sendMessage("§aĐã chọn gửi lì xì " + type.name() + " với số lượng " + amount);
                // TODO: Tiếp tục chọn người nhận hoặc phát
            }
        }

        if (title.equals("§aChọn người nhận lì xì")) {
            if (item.getType() == Material.PLAYER_HEAD) {
                String name = item.getItemMeta().getDisplayName().replace("§e", "");
                Player target = Bukkit.getPlayerExact(name);
                if (target != null) {
                    LixiSession.addRecipient(player.getUniqueId(), target.getUniqueId());
                    player.sendMessage("§aĐã chọn " + name + " để nhận lì xì.");
                }
            } else if (item.getType() == Material.EMERALD_BLOCK) {
                int amount = LixiSession.getAmount(player.getUniqueId());
                LixiSession.LixiType type = LixiSession.getType(player.getUniqueId());
                java.util.List<UUID> targets = LixiSession.getRecipients(player.getUniqueId());

                if (targets.isEmpty()) {
                    player.sendMessage("§cBạn chưa chọn người nhận!");
                    return;
                }

                double splitAmount = amount * 1.0 / targets.size();

                for (UUID targetUuid : targets) {
                    Player target = Bukkit.getPlayer(targetUuid);
                    if (target == null) continue;

                    if (type == LixiSession.LixiType.MONEY) {
                        me.dihoa.liximayman.utils.VaultUtils.deposit(target, splitAmount);
                    } else {
                        me.dihoa.liximayman.utils.PlayerPointsUtils.givePoints(target, (int) splitAmount);
                    }

                    target.sendTitle("§6🎉 Bạn nhận được lì xì!", "§fTừ " + player.getName(), 10, 60, 10);
                }

                player.sendMessage("§aĐã gửi lì xì thành công cho " + targets.size() + " người.");
                LixiSession.clearAll(player.getUniqueId());
                player.closeInventory();
            }
        }

        if (title.equals("§bChọn chế độ phát lì xì")) {
            if (item.getType() == Material.NAME_TAG) {
                player.sendMessage("§aBạn đã chọn chế độ phát: cá nhân.");
                me.dihoa.liximayman.guis.GUIPlayerSelector.open(player);
            } else if (item.getType() == Material.BEACON) {
                player.closeInventory();
                int amount = LixiSession.getAmount(player.getUniqueId());
                LixiSession.LixiType type = LixiSession.getType(player.getUniqueId());

                java.util.List<Player> players = Bukkit.getOnlinePlayers().stream()
                    .filter(p -> !p.equals(player))
                    .toList();

                if (players.isEmpty()) {
                    player.sendMessage("§cKhông có ai online để nhận lì xì.");
                    return;
                }

                double split = amount * 1.0 / players.size();

                for (Player p : players) {
                    if (type == LixiSession.LixiType.MONEY) {
                        me.dihoa.liximayman.utils.VaultUtils.deposit(p, split);
                    } else {
                        me.dihoa.liximayman.utils.PlayerPointsUtils.givePoints(p, (int) split);
                    }
                    p.sendTitle("§6🎉 Bạn nhận được lì xì!", "§fTừ " + player.getName(), 10, 60, 10);
                }

                player.sendMessage("§aĐã phát lì xì chia đều cho toàn bộ người chơi.");
                LixiSession.clearAll(player.getUniqueId());

            } else if (item.getType() == Material.ENDER_PEARL) {
                player.closeInventory();
                int amount = LixiSession.getAmount(player.getUniqueId());
                LixiSession.LixiType type = LixiSession.getType(player.getUniqueId());

                java.util.List<Player> players = new java.util.ArrayList<>(Bukkit.getOnlinePlayers());
                players.remove(player);

                java.util.Collections.shuffle(players);
                int count = Math.min(3, players.size());
                players = players.subList(0, count);

                if (players.isEmpty()) {
                    player.sendMessage("§cKhông có ai online để nhận lì xì.");
                    return;
                }

                double split = amount * 1.0 / players.size();
                for (Player p : players) {
                    if (type == LixiSession.LixiType.MONEY) {
                        me.dihoa.liximayman.utils.VaultUtils.deposit(p, split);
                    } else {
                        me.dihoa.liximayman.utils.PlayerPointsUtils.givePoints(p, (int) split);
                    }
                    p.sendTitle("§6🎉 Bạn nhận được lì xì!", "§fTừ " + player.getName(), 10, 60, 10);
                }

                player.sendMessage("§aĐã phát lì xì ngẫu nhiên cho " + count + " người.");
                LixiSession.clearAll(player.getUniqueId());
            }
        }
