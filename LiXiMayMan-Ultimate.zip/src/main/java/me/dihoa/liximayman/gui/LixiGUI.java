package me.dihoa.liximayman.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class LixiGUI {
    public static void openMainGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, "Phát Lì Xì / Lì Xì May Mắn");

        ItemStack money = new ItemStack(Material.GOLD_INGOT);
        ItemMeta moneyMeta = money.getItemMeta();
        moneyMeta.setDisplayName("§eLì Xì Loại: Money");
        moneyMeta.setLore(Arrays.asList("§7Tổng tiền Lì xì: 0.0", "§aNhấn vào đây để nhập"));
        money.setItemMeta(moneyMeta);

        ItemStack point = new ItemStack(Material.EMERALD);
        ItemMeta pointMeta = point.getItemMeta();
        pointMeta.setDisplayName("§eLì Xì Loại: Point");
        pointMeta.setLore(Arrays.asList("§7Tổng tiền Lì xì: 0.0", "§aNhấn vào đây để nhập"));
        point.setItemMeta(pointMeta);

        ItemStack confirm = new ItemStack(Material.LIME_CONCRETE);
        ItemMeta confirmMeta = confirm.getItemMeta();
        confirmMeta.setDisplayName("§a§lXác nhận phát Lì Xì");
        confirm.setItemMeta(confirmMeta);

        gui.setItem(10, money);
        gui.setItem(12, point);
        gui.setItem(16, confirm);

        player.openInventory(gui);
    }
}
