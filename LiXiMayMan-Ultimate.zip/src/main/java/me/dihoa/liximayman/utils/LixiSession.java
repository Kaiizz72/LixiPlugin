package me.dihoa.liximayman.utils;

import java.util.HashMap;
import java.util.UUID;

public class LixiSession {
    private static final HashMap<UUID, java.util.List<UUID>> recipients = new HashMap<>();

    public static void addRecipient(UUID owner, UUID target) {
        recipients.computeIfAbsent(owner, k -> new java.util.ArrayList<>()).add(target);
    }

    public static java.util.List<UUID> getRecipients(UUID owner) {
        return recipients.getOrDefault(owner, new java.util.ArrayList<>());
    }

    public static void clearAll(UUID uuid) {
        selectedType.remove(uuid);
        selectedAmount.remove(uuid);
        recipients.remove(uuid);
    }

    private static final HashMap<UUID, Integer> selectedAmount = new HashMap<>();

    public static void setAmount(UUID uuid, int amount) {
        selectedAmount.put(uuid, amount);
    }

    public static int getAmount(UUID uuid) {
        return selectedAmount.getOrDefault(uuid, 0);
    }

    public enum LixiType { MONEY, POINT }

    private static final HashMap<UUID, LixiType> selectedType = new HashMap<>();

    public static void setType(UUID uuid, LixiType type) {
        selectedType.put(uuid, type);
    }

    public static LixiType getType(UUID uuid) {
        return selectedType.getOrDefault(uuid, LixiType.MONEY);
    }

    public static void clear(UUID uuid) {
        selectedType.remove(uuid);
    }
}
