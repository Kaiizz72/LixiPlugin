package me.dihoa.liximayman.managers;

import org.black_ixx.playerpoints.PlayerPoints;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PlayerPointsHook {
    private static PlayerPointsAPI ppAPI = null;

    public static boolean setup() {
        if (Bukkit.getPluginManager().getPlugin("PlayerPoints") == null) return false;
        PlayerPoints plugin = (PlayerPoints) Bukkit.getPluginManager().getPlugin("PlayerPoints");
        ppAPI = plugin.getAPI();
        return ppAPI != null;
    }

    public static PlayerPointsAPI get() {
        return ppAPI;
    }

    public static boolean hasEnough(Player player, int amount) {
        return ppAPI.getPoints(player.getUniqueId()) >= amount;
    }

    public static void givePoints(Player player, int amount) {
        ppAPI.give(player.getUniqueId(), amount);
    }

    public static void takePoints(Player player, int amount) {
        ppAPI.take(player.getUniqueId(), amount);
    }
}
