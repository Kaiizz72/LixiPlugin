package me.dihoa.liximayman.managers;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.List;

public class LixiManager {
    public static boolean sendLixiMoney(Player sender, List<Player> receivers, double totalAmount) {
        if (receivers.isEmpty()) return false;

        Economy econ = VaultHook.getEconomy();
        if (econ == null) return false;

        if (econ.getBalance(sender) < totalAmount) {
            sender.sendMessage("§cBạn không đủ tiền để phát lì xì.");
            return false;
        }

        double perPlayer = totalAmount / receivers.size();
        econ.withdrawPlayer(sender, totalAmount);

        for (Player p : receivers) {
            econ.depositPlayer(p, perPlayer);
            p.sendTitle("§6§l🎉 BẠN ĐÃ NHẬN LÌ XÌ!", "§a+ " + perPlayer + " tiền từ " + sender.getName(), 10, 70, 20);
        }

        sender.sendMessage("§aĐã phát lì xì thành công cho " + receivers.size() + " người.");
        return true;
    }
}

    public static boolean sendLixiPoints(Player sender, List<Player> receivers, int totalPoints) {
        if (receivers.isEmpty()) return false;

        if (!PlayerPointsHook.hasEnough(sender, totalPoints)) {
            sender.sendMessage("§cBạn không đủ Point để phát lì xì.");
            return false;
        }

        int perPlayer = totalPoints / receivers.size();
        PlayerPointsHook.takePoints(sender, totalPoints);

        for (Player p : receivers) {
            PlayerPointsHook.givePoints(p, perPlayer);
            p.sendTitle("§d§l🎁 BẠN ĐÃ NHẬN LÌ XÌ!", "§a+ " + perPlayer + " point từ " + sender.getName(), 10, 70, 20);
        }

        sender.sendMessage("§aĐã phát lì xì Point cho " + receivers.size() + " người.");
        return true;
    }
