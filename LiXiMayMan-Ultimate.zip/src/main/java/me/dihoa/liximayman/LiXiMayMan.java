package me.dihoa.liximayman;

import me.dihoa.liximayman.commands.LixiCommand;
import me.dihoa.liximayman.listeners.GUIListener;
import me.dihoa.liximayman.managers.PlayerPointsHook;
import me.dihoa.liximayman.managers.VaultHook;
import org.bukkit.plugin.java.JavaPlugin;

public class LiXiMayMan extends JavaPlugin {
    private static LiXiMayMan instance;

    @Override
    public void onEnable() {
        instance = this;
        getLogger().info("LiXiMayMan đã được bật!");
        saveDefaultConfig();
        if (!VaultHook.setupEconomy()) {
            getLogger().severe("Không tìm thấy Vault. Plugin sẽ tắt.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (!PlayerPointsHook.setup()) {
            getLogger().severe("Không tìm thấy PlayerPoints. Plugin sẽ tắt.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        registerCommands();
        registerEvents();
    }

    @Override
    public void onDisable() {
        getLogger().info("LiXiMayMan đã tắt.");
    }

    public static LiXiMayMan getInstance() {
        return instance;
    }

    private void registerCommands() {
        getCommand("lixi").setExecutor(new LixiCommand());
        getCommand("nhanlixi").setExecutor(new LixiCommand());
    }

    private void registerEvents() {
        getServer().getPluginManager().registerEvents(new GUIListener(), this);
    }
}
